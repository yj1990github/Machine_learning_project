# Sparse-Autoencoder
This is an implementation of the sparse auto-encoder algorithm. It is one of the assignments from CS 294 taught by Andrew Ng at Stanford University. The complete assignment can be found at http://ufldl.stanford.edu/wiki/index.php/Exercise:Sparse_Autoencoder
